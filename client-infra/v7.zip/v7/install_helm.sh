#!/bin/bash
set -e

NAMESPACE="client-system"

echo "✅ 1. Helm 설치 여부 확인..."
if ! command -v helm &> /dev/null; then
  echo "❌ Helm이 설치되어 있지 않습니다. 설치를 시작합니다..."
  curl https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 | bash
else
  echo "✅ Helm이 이미 설치되어 있습니다."
fi

echo ""
echo "✅ 2. Helm repo 추가 및 업데이트..."
helm repo add bitnami https://charts.bitnami.com/bitnami || true
helm repo add grafana https://grafana.github.io/helm-charts || true
helm repo add traefik https://traefik.github.io/charts || true
helm repo update

echo ""
echo "✅ 3. PostgreSQL 설치 시작..."
if helm list -n $NAMESPACE | grep -q postgresql-svc; then
  echo "ℹ️ postgresql-svc 이미 설치되어 있음. 생략합니다."
else
  helm install postgresql-svc bitnami/postgresql \
    --namespace $NAMESPACE \
    --create-namespace \
    --set auth.username=sesim,auth.password=sesimS109!,auth.database=sesim
fi

echo ""
echo "✅ 4. Grafana 대시보드 ConfigMap 생성..."
sudo kubectl create configmap grafana-dashboard-config \
  --namespace $NAMESPACE \
  --from-file=model1_dashboard.json \
  --dry-run=client -o yaml | sudo kubectl apply -f -

echo ""
echo "✅ 5. Grafana 설치 시작 (Values 파일 적용)..."
if helm list -n $NAMESPACE | grep -q grafana-svc; then
  echo "ℹ️ grafana-svc 이미 설치되어 있음. 생략합니다."
else
  helm install grafana-svc grafana/grafana \
    --namespace $NAMESPACE \
    -f grafana-values.yaml
fi

echo ""
echo "✅ 6. Traefik 설치 시작 (NodePort)..."
if helm list -n $NAMESPACE | grep -q traefik; then
  echo "ℹ️ traefik 이미 설치되어 있음. 생략합니다."
else
  helm install traefik traefik/traefik \
    --namespace $NAMESPACE \
    --set service.type=NodePort \
    --set ports.web.port=80 \
    --set ports.web.nodePort=31080 \
    --set ports.websecure.port=443 \
    --set ports.websecure.nodePort=31443
fi

echo ""
echo "✅ 7. AI 서버(ai-server-svc) 설치 시작 (ClusterIP + Ingress)..."
if helm list -n $NAMESPACE | grep -q ai-server-svc; then
  echo "ℹ️ ai-server-svc 이미 설치되어 있음. 생략합니다."
else
  if [ -d "./ai-server-chart" ]; then
    helm install ai-server-svc1 ./ai-server-chart \
      --namespace $NAMESPACE
  else
    echo "❌ ai-server-chart 디렉토리가 존재하지 않습니다."
    echo "⚠️ ai-server-chart 디렉토리를 준비하고 다시 실행해주세요."
    exit 1
  fi
fi

echo ""
echo "✅ 8. Backend 서버(FastAPI) 설치 시작 (ClusterIP + Ingress)..."
if helm list -n $NAMESPACE | grep -q backend-svc; then
  echo "ℹ️ backend-svc 이미 설치되어 있음. 생략합니다."
else
  if [ -d "./backend-chart" ]; then
    helm install backend-svc ./backend-chart \
      --namespace $NAMESPACE \
      --set service.type=ClusterIP \
      --set ingress.enabled=true
  else
    echo "❌ backend-chart 디렉토리가 존재하지 않습니다."
    echo "⚠️ backend-chart 디렉토리를 준비하고 다시 실행해주세요."
    exit 1
  fi
fi

echo ""
echo "✅ 9. Grafana Ingress 리소스 생성 중..."
cat <<EOF | sudo kubectl apply -f -
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: grafana-ingress
  namespace: ${NAMESPACE}
  annotations:
    kubernetes.io/ingress.class: traefik
spec:
  rules:
    - http:
        paths:
          - path: /grafana
            pathType: Prefix
            backend:
              service:
                name: grafana-svc
                port:
                  number: 80
EOF

echo ""
echo "🎉 모든 설치 완료!"
echo "✅ 대시보드: http://<EC2_IP>:31080/grafana"
echo "✅ API: http://<EC2_IP>:31080/api/docs"