#!/bin/bash
# install_k3s_server.sh (워크 노드 자동 설치 포함)
# 사용법: ./install_k3s.sh your-key.pem ubuntu 172.31.31.100 172.31.31.101

set -e

### 0. 인자 확인
if [ "$#" -lt 3 ]; then
  echo "❌ 사용법: $0 <pem_key_path> <username> <worker_ip_1> [worker_ip_2 ...]"
  exit 1
fi

PEM_FILE="$1"
USERNAME="$2"
shift 2
WORKER_IPS=("$@")

### 0.5. pem 파일 권한 설정
echo "🔐 pem 파일 권한 설정 (chmod 600 $PEM_FILE)"
chmod 600 "$PEM_FILE"

### 1. 서버 설치
echo "✅ 현재 서버 (control-plane)에 k3s 설치 중..."
curl -sfL https://get.k3s.io | INSTALL_K3S_EXEC="--disable=traefik" sh -

echo "✅ k3s server 설치 완료!"
SERVER_IP=$(hostname -I | awk '{print $1}')
echo "🔹 서버 Private IP: $SERVER_IP"

NODE_TOKEN=$(sudo cat /var/lib/rancher/k3s/server/node-token)
echo "🔹 Node Token: $NODE_TOKEN"

### 2. kubeconfig 설정
echo "✅ kubeconfig 설정 중..."
mkdir -p ~/.kube
sudo cp /etc/rancher/k3s/k3s.yaml ~/.kube/config
sudo chown $(id -u):$(id -g) ~/.kube/config

### 3. 네임스페이스 생성
echo "✅ client-system 네임스페이스 생성 중..."
sudo kubectl create namespace client-system || echo "⚠️ 이미 존재하는 네임스페이스입니다."

### 4. 워커 노드 자동 설치
echo ""
echo "✅ 워커 노드에 K3s agent 설치 시작..."

for ip in "${WORKER_IPS[@]}"; do
  echo "🔹 워커 노드 접속 중: $ip"
  ssh -o StrictHostKeyChecking=no -i "$PEM_FILE" "$USERNAME@$ip" << EOF
    curl -sfL https://get.k3s.io | env K3S_URL="https://$SERVER_IP:6443" K3S_TOKEN="$NODE_TOKEN" sh -
EOF
  echo "✅ 워커 노드 $ip 설치 완료!"
done

echo ""
echo "🎉 모든 워커 노드 설치 완료!"
