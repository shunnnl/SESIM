#!/bin/bash
set -e

# 사용법 안내
if [ "$#" -lt 3 ]; then
  echo "❌ 사용법: $0 <pem_key_file> <ssh_username> <worker_ip_1> [worker_ip_2 ...]"
  exit 1
fi

PEM_FILE=$1
USERNAME=$2
shift 2
WORKER_IPS=("$@")

### 1. K3s 설치 (서버 + 워커 자동화)
echo ""
echo "🚀 Step 1: K3s 서버 및 워커 노드 설치 시작..."
bash ./install_k3s.sh "$PEM_FILE" "$USERNAME" "${WORKER_IPS[@]}"

### 2. Helm 기반 서비스 설치
echo ""
echo "🚀 Step 2: Helm 기반 애플리케이션 설치 (Postgres, Grafana, Traefik, Backend)..."
bash ./install_helm.sh

### 3. EC2 Nginx 프록시 설정
echo ""
echo "🚀 Step 3: EC2 리버스 프록시(Nginx + Docker) 설정 시작..."
bash ./install_nginx_proxy.sh

echo ""
echo "🎉 전체 설치 완료!"
echo "📌 접속 확인: http://<EC2_PUBLIC_IP>/api, http://<EC2_PUBLIC_IP>/grafana"
