#!/bin/bash
set -e

# 설정
NODEPORT_HTTP=31080  # Traefik Ingress가 사용하는 NodePort
NGINX_DIR=~/nginx-proxy
NGINX_CONF=$NGINX_DIR/conf/nginx.conf

echo "✅ 0. Docker 설치 여부 확인..."
if ! command -v docker &> /dev/null
then
    echo "❌ Docker가 설치되어 있지 않습니다. 설치를 시작합니다..."
    curl -fsSL https://get.docker.com | sh
    sudo usermod -aG docker $USER
    echo "⚠️ Docker 그룹 적용을 위해 터미널을 재시작하거나 'newgrp docker'를 실행하세요."
else
    echo "✅ Docker가 이미 설치되어 있습니다."
fi

echo "✅ 1. Nginx 리버스 프록시 디렉토리 생성 중..."
mkdir -p $NGINX_DIR/conf

echo "✅ 2. nginx.conf 생성 중..."
cat <<EOF > $NGINX_CONF
events {}

http {
    client_max_body_size 20M;

    server {
        listen 80;
        server_name _;

        location /api {
            proxy_pass http://host.docker.internal:${NODEPORT_HTTP}/api;
            proxy_set_header Host \$host;
            proxy_set_header X-Real-IP \$remote_addr;
        }

        location /grafana {
            proxy_pass http://host.docker.internal:${NODEPORT_HTTP}/grafana;
            proxy_set_header Host \$host;
            proxy_set_header X-Real-IP \$remote_addr;
        }

        location /api/admin/train/upload {
            client_max_body_size 5G;
        }
    }
}
EOF

echo "✅ 3. 기존 Nginx 컨테이너 종료 및 삭제 (있다면)..."
sudo docker rm -f nginx-proxy 2>/dev/null || true

echo "✅ 4. Nginx Docker 컨테이너 실행 중..."
sudo docker run -d \
  --name nginx-proxy \
  -p 80:80 \
  -v $NGINX_CONF:/etc/nginx/nginx.conf:ro \
  --add-host=host.docker.internal:host-gateway \
  nginx:latest

echo ""
echo "🎉 EC2의 80포트에서 Traefik NodePort(${NODEPORT_HTTP})로 리버스 프록시 설정 완료!"
echo "🔗 테스트 URL 예시: http://<EC2_PUBLIC_IP>/api 또는 /grafana"
